﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoSalesSystem
{
    public enum Provinces
    {
        Alberta, British_Columbia, Manitoba, New_Brunswick, Newfoundland_and_Labrador, Nova_Scotia,
        Northwest_Territories, Nunavut, Ontario, Prince_Edward_Island, Quebec,
        Saskatchewan, Yukon
    }
}
