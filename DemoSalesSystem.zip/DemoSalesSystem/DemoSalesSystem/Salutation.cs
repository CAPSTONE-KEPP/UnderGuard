﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoSalesSystem
{
    public enum Salutation
    {
        Mr, Mrs, Ms, Dr, Rev
    }
}
